<h1> Big Red Bids (iOS) - Cornell AppDev Hack Challenge Fall '23 </h1>

Big Red Bids is a ticket resale app where members of the Cornell community can bid on or auction tickets for campus events with ease. The main features include creating auctions for event tickets, placing bids on event tickets, and checking the status of ongoing auctions. After creating an account, users can both buy and sell, all in one convenient app!

Backend repository: https://github.com/czhu0205/hack-challenge

Group: <br> <b> iOS Developers: </b> Daniel Xie, Kevin Lee <br> <b> Backend Developers: </b> Caroline Zhu, Aiden Joo <br> <b> Product Designer: </b> Shirley Yuan

Created for Cornell Hack Challenge - Fall 2023
